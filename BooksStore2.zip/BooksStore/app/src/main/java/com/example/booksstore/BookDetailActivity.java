package com.example.booksstore;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BookDetailActivity extends AppCompatActivity {

    ImageView saveButton, closeButton, bookImage;
    TextView bookTitle, bookAuthors, bookYear, bookRating, bookDescription;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        saveButton = (ImageView) findViewById(R.id.saveButton);
        closeButton = (ImageView) findViewById(R.id.closeButon);
        bookImage = (ImageView) findViewById(R.id.bookImg);
        bookTitle = (TextView) findViewById(R.id.bookTitle);
        bookAuthors = (TextView) findViewById(R.id.textAuthors);
        bookYear = (TextView) findViewById(R.id.publishDate);
        bookRating = (TextView) findViewById(R.id.rating);
        bookDescription = (TextView) findViewById(R.id.bookDescription);


    }

}
