package com.example.booksstore.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.booksstore.R;
import com.example.booksstore.fragment.BookFragment;
import com.example.booksstore.interfaces.BookClickInterface;
import com.example.booksstore.model.BookResponseModel;

import java.util.ArrayList;

public class SectionAdapter extends RecyclerView.Adapter<SectionAdapter.SectionViewHolder>{

    ArrayList<BookResponseModel> bookList;
    LayoutInflater inflater;
    Context context;
    BookClickInterface bookClickInterface;

    public SectionAdapter(Context context, ArrayList<BookResponseModel>  bookList, BookClickInterface clickInterface) {
        this.context = context;
        this.bookClickInterface = clickInterface;
        this.bookList = bookList;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public SectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.recyclerview_item_section, parent, false);
        return new SectionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SectionViewHolder holder, int position) {
        BookResponseModel bookResponse = bookList.get(position);
        BookAdapter bookAdapter = new BookAdapter(context, bookResponse.getItems(), bookClickInterface);
        if (holder.recyclerView == null){
            Log.d("REC ERROR", "error");
        }
        holder.recyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        holder.recyclerView.setAdapter(bookAdapter);

        switch (bookResponse.getSectionType()){
            case BookFragment.HEALTHY_LIFESTYLE:
                holder.sectionTitle.setText(context.getResources().getString(R.string.healthy_lifestyle));
                break;
            case BookFragment.WELLNESS:
                holder.sectionTitle.setText(context.getResources().getString(R.string.wellness));
                break;
            case BookFragment.HEALTHY_MEALS:
                holder.sectionTitle.setText(context.getResources().getString(R.string.healtjy_meals));
                break;
        }

    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    public class SectionViewHolder extends RecyclerView.ViewHolder {
        TextView sectionTitle;
        RecyclerView recyclerView;

        public SectionViewHolder(@NonNull View itemView) {
            super(itemView);
            sectionTitle = (TextView) itemView.findViewById(R.id.section_title);
            recyclerView = (RecyclerView) itemView.findViewById(R.id.recycler_view_items);
        }
    }
}
